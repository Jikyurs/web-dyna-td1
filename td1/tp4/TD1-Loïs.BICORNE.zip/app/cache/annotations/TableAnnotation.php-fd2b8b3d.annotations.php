<?php

return array(
  '#namespace' => 'Ubiquity\\annotations',
  '#uses' => array (
),
  '#traitMethodOverrides' => array (
  'Ubiquity\\annotations\\TableAnnotation' => 
  array (
  ),
),
  'Ubiquity\\annotations\\TableAnnotation' => array(
    array('#name' => 'usage', '#type' => 'mindplay\\annotations\\UsageAnnotation', 'class'=>true, 'inherited'=>true)
  ),
);

